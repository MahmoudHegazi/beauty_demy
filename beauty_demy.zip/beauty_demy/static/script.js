$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {
    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== ""){
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top - 30
      }, 900, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
})


// shake $( document ).click(function() {
// define global vars
const sections = document.querySelectorAll('.udacity');
const nav_links= document.querySelectorAll('a.nav-link');
const second_back = document.querySelector('#second_back_btn');
const main_back_btn = document.querySelector('#main_back_btn');



function remover() {
     sections.forEach( (elm)=> { 
        elm.classList.remove("udacity_active");
});

     
}


        function link_removers(){
        nav_links.forEach( (link_edit)=> { 
           link_edit.classList.remove("udacity_active_link");
        });
        }

function myscroll() {



function x() {
$("#shaked_flower").effect( "shake", {times:2}, 1500 );
}

sections.forEach( (section)=> { 
  //alert(section.id);
  let rect = section.getBoundingClientRect();
  let top = rect.top;
  let bottom = rect.bottm;
  let hight = rect.height;
  let avg = hight - window.innerHeight;
  if(!$(window).scrollTop()) { 
  //abuse 0 == false :)
    remover();
    link_removers();

     x();
  }
  if (top > 0 && rect.bottom < window.innerHeight + avg + 50) {
  

     remover();
     section.classList.add("udacity_active");
     // show the second back to top btn     
     second_back.style.display = "block";
     
     // hide the main back btn
     main_back_btn.style.visibility = "hidden";
     let active_section = section;
     
     function checklink(active_section) {
     nav_links.forEach( (link)=> { 
        let section_id = link.getAttribute('data-nav');
        if ( active_section.id == section_id) {
        
        // remove old classess
        

        link_removers();
          // give the active link active class
          link.classList.add("udacity_active_link");

        }
     });
     }
     checklink(active_section);
     
  } 
})

}
window.addEventListener('scroll', myscroll);



$(window).scroll(function() {
    clearTimeout($.data(this, 'scrollTimer'));
    $.data(this, 'scrollTimer', setTimeout(function() {
        // do something
       remover();
       link_removers();
       second_back.style.display = "none";
    }, 3000));
});

// check if user scrolled to the bottom
// remove links class
$(window).scroll(function() {
   if($(window).scrollTop() + $(window).height() == $(document).height()) {
   
      remover();
      link_removers();
      second_back.style.display = "none";
      main_back_btn.style.visibility = "visible";

   }
});

// back to top smoth scroll action and hide + hide nav

let navs = document.querySelector('#second_btn_back_span');
second_back.addEventListener('click', (event)=> {
  event.preventDefault();
        navs.style.display = "block";
        navs.scrollIntoView({behavior: "smooth"});
        navs.style.display = "none";
});


let show_notdone = document.getElementById('we_still_edit');
show_notdone.addEventListener('click', ()=> {
	alert('Sorry We Are Working On Building the ClassRoom It not Read Please Check the Website to Know What we Provide Thank you for Visiting Beauty Demy');
});