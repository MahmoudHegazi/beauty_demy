#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from flask import Flask, render_template, request, redirect, jsonify, url_for, flash
from sqlalchemy import create_engine, asc
from sqlalchemy.orm import sessionmaker
from database_setup import Base, User, Home, CoursesMenu, LessonsMenu, Lesson, LessonsMeta, UsersMessages, OuterMessages, News
from flask import session as login_session
import random
import string

# IMPORTS FOR THIS STEP
#from oauth2client.client import flow_from_clientsecrets
#from oauth2client.client import FlowExchangeError
import httplib2
import json
from flask import make_response
import requests
app = Flask(__name__)


engine = create_engine('sqlite:///makup.db')
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
session = DBSession()


# home
@app.route('/', methods=['GET'])
@app.route('/home', methods=['GET'])
@app.route('/beautydemy', methods=['GET'])

def home():
    return render_template('index.html')
		
		



if __name__ == '__main__':
    app.secret_key = 'super_s**/S**Q//E*@//$ecretf.;.p44o32o0oo44985*&*&@^@%@$##@#@@%%@%@@%ffff325345%^^^@^@^@&@&&66<MMjuapppppppppki99&*&&&*P:><<<MM1122_key'
    app.debug = True
    app.run(host='0.0.0.0', port=8000, threaded=False)